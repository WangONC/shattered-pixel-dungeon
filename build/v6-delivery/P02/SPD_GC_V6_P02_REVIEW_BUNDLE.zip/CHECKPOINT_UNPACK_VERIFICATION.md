# P02 Checkpoint 解压副本复验报告

- Status: PASS
- Checkpoint: SPD_GC_V6_P02_BUILDER_CHECKPOINT.zip
- Checkpoint SHA-256: 8f4c0548e218e124d95dff52bda72572fcd0b56b08b78caee5087a59ea9b28b6
- Source manifest SHA-256: d7d98c608ce3cb5de258de95f37383d1f02d79a8386c13d787b372451cb2da59
- Verified source files: 2198
- Forbidden checkpoint content (.git/.gradle/.idea/build/local.properties/signing binaries): absent
- Unpacked gate status: PASS
- Unpacked gate count: 10
- Unpacked gate results: checkpoint-verification/gates/P02_GATE_RESULTS.json
- Unpacked logs: checkpoint-verification/gates/logs/
