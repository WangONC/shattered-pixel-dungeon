# P02-R1 Checkpoint 解压副本复验报告

- Status: PASS
- Checkpoint: SPD_GC_V6_P02_R1_CHECKPOINT.zip
- Checkpoint SHA-256: 65249b50e48d1788724512c8a4aba6314c4814976adea59e6b42369b1de983d5
- Source manifest SHA-256: 24f627329e532b5a2eb60e6c385050e0cf4efc3c53544b1e29e002f11a81c1ff
- Verified source files: 2204
- Forbidden checkpoint content (.git/.gradle/.idea/build/local.properties/signing binaries): absent
- Unpacked gate status: PASS
- Unpacked gate count: 11
- Unpacked gate results: checkpoint-verification/gates/P02_GATE_RESULTS.json
- Unpacked logs: checkpoint-verification/gates/logs/
